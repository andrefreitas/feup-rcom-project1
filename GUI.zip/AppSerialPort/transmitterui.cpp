#include "transmitterui.h"
#include "ui_transmitterui.h"
#include "processingui.h"

#include <QDialog>
#include <QtCore>
#include <QtGui>

using namespace std;

transmitterUI::transmitterUI(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::transmitterUI)
{
    ui->setupUi(this);
    ui->textBrowser->setText("/usr/users2/mieic2010/ei10086/Desktop/pinguim.gif");
    filePath = "/usr/users2/mieic2010/ei10086/Desktop/pinguim.gif";
    ui->lineEdit->setText("B38400");

    newExp = new dialogExplorer();
    connect(newExp,SIGNAL(accepted()),this,SLOT(on_newExp_accepted()));
}

transmitterUI::~transmitterUI()
{
    delete ui;
}

void transmitterUI::on_pushButton_clicked()
{
    newExp->show();
}

void transmitterUI::on_newExp_accepted() {
    ui->textBrowser->setText(newExp->getPath());
    filePath = newExp->getPath().toStdString();
}

void transmitterUI::on_pushButton_2_clicked()
{
    exit(-1);
}

void transmitterUI::on_transf_accepted() {
    this->show();
}

void transmitterUI::on_pushButton_3_clicked()
{
    int argc = 16;
    char **argv = new char*[argc];
    char temp[20];

    for (int i = 0; i < argc; i++) argv[i] = new char[100];

    strcpy(argv[0], "nserial");
    strcpy(argv[1], "transmitter");
    strcpy(argv[2], "-l");
    strcpy(argv[3], (char *) filePath.c_str());

    strcpy(argv[4], "-t");
    sprintf(temp, "%d",ui->spinBox->value());
    strcpy(argv[5], temp);

    strcpy(argv[6], "-s");
    sprintf(temp, "%d",ui->spinBox_2->value());
    strcpy(argv[7], temp);

    strcpy(argv[8], "-restore");
    if (ui->checkBox->isChecked()) strcpy(argv[9], "1");
    else strcpy(argv[9], "0");

    strcpy(argv[10], "-r");
    sprintf(temp, "%d",ui->spinBox_4->value());
    strcpy(argv[11], temp);

    strcpy(argv[12], "-error");
    sprintf(temp, "%d",ui->spinBox_5->value());
    strcpy(argv[13], temp);

    if (ui->lineEdit->text().operator !=("B38400")) {
        strcpy(argv[14], "-b");
        strcpy(argv[15], (char *) ui->lineEdit->text().toStdString().c_str());
    } else argc -= 2;

    appLayer * app = new appLayer();
    app->buildArgs(argc,argv);

    processingUI * transf = new processingUI();
    transf->setAppLayer(app);
    transf->show();
    this->hide();
    transf->setTransf(TRANSMITTER);

    connect(transf,SIGNAL(accepted()),this,SLOT(on_transf_accepted()));
}
