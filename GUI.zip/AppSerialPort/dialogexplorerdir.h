#ifndef DIALOGEXPLORERDIR_H
#define DIALOGEXPLORERDIR_H

#include <QDialog>
#include <QtCore>
#include <QtGui>

using namespace std;

namespace Ui {
class dialogExplorerDir;
}

class dialogExplorerDir : public QDialog
{
    Q_OBJECT
    
public:
    explicit dialogExplorerDir(QWidget *parent = 0);
    ~dialogExplorerDir();
    QString getPath();

private slots:
    void on_treeView_clicked(const QModelIndex &index);
    void on_pushButton_2_clicked();

private:
    Ui::dialogExplorerDir *ui;
    QFileSystemModel *model;
    QFileInfo currentFile;
    QString currentPath;

};

#endif // DIALOGEXPLORERDIR_H
