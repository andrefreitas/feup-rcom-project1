#include "dialogexplorer.h"
#include "ui_dialogexplorer.h"

dialogExplorer::dialogExplorer(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dialogExplorer)
{
    ui->setupUi(this);
    currentPath = "/";

    model = new QFileSystemModel(this);
    model->setRootPath(currentPath);
    ui->treeView->setModel(model);
    ui->treeView->setColumnWidth(0,370);
    ui->treeView->setColumnHidden(2,true);
    ui->treeView->setColumnHidden(3,true);

    ui->pushButton_2->setEnabled(false);
}

dialogExplorer::~dialogExplorer()
{
    delete ui;
}

QString dialogExplorer::getPath() {
    return currentPath;
}


void dialogExplorer::on_treeView_clicked(const QModelIndex &index) {
    currentFile = model->fileInfo(index);
    if (!currentFile.isFile()) ui->pushButton_2->setEnabled(false);
    else ui->pushButton_2->setEnabled(true);
}

void dialogExplorer::on_pushButton_2_clicked() {
    if (currentFile.isFile()) currentPath = currentFile.absoluteFilePath();
    this->accept();
}
