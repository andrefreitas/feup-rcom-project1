#ifndef RECEIVERUI_H
#define RECEIVERUI_H

#include <QDialog>
#include "dialogexplorerdir.h"

#include <string>

using namespace std;

namespace Ui {
class receiverUI;
}

class receiverUI : public QDialog
{
    Q_OBJECT
    
public:
    explicit receiverUI(QWidget *parent = 0);
    ~receiverUI();
    
private slots:
    void on_pushButton_clicked();
    void on_newExp_accepted();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_transf_accepted();

private:
    Ui::receiverUI *ui;
    dialogExplorerDir *newExp;
    string filePath;
};

#endif
