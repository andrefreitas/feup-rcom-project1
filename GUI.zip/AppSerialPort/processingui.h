#ifndef PROCESSINGUI_H
#define PROCESSINGUI_H

#include <QDialog>
#include "appLayer.h"

namespace Ui {
class processingUI;
}

class processingUI : public QDialog
{
    Q_OBJECT
    
public:
    explicit processingUI(QWidget *parent = 0);
    ~processingUI();
    void setAppLayer(appLayer * app);
    void setTransf(int who);

private slots:

private:
    Ui::processingUI *ui;
    appLayer * app;

};

#endif // PROCESSINGUI_H
