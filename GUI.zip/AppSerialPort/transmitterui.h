#ifndef TRANSMITTERUI_H
#define TRANSMITTERUI_H

#include <QDialog>
#include "dialogexplorer.h"

#include <string>

using namespace std;

namespace Ui {
class transmitterUI;
}

class transmitterUI : public QDialog
{
    Q_OBJECT
    
public:
    explicit transmitterUI(QWidget *parent = 0);
    ~transmitterUI();
    
private slots:
    void on_pushButton_clicked();
    void on_newExp_accepted();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_transf_accepted();

private:
    Ui::transmitterUI *ui;
    dialogExplorer *newExp;
    string filePath;
};

#endif // TRANSMITTERUI_H
