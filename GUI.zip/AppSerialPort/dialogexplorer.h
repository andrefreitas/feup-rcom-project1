#ifndef DIALOGEXPLORER_H
#define DIALOGEXPLORER_H

#include <QDialog>
#include <QtCore>
#include <QtGui>

using namespace std;

namespace Ui {
class dialogExplorer;
}

class dialogExplorer : public QDialog
{
    Q_OBJECT
    
public:
    explicit dialogExplorer(QWidget *parent = 0);
    ~dialogExplorer();
    QString getPath();

private slots:
    void on_treeView_clicked(const QModelIndex &index);
    void on_pushButton_2_clicked();

private:
    Ui::dialogExplorer *ui;
    QFileSystemModel *model;
    QFileInfo currentFile;
    QString currentPath;

};

#endif // DIALOGEXPLORER_H
