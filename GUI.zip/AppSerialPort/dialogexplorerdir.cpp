#include "dialogexplorerdir.h"
#include "ui_dialogexplorerdir.h"

dialogExplorerDir::dialogExplorerDir(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dialogExplorerDir)
{
    ui->setupUi(this);
    currentPath = "/";

    model = new QFileSystemModel(this);
    model->setRootPath(currentPath);
    ui->treeView->setModel(model);
    ui->treeView->setColumnWidth(0,370);
    ui->treeView->setColumnHidden(2,true);
    ui->treeView->setColumnHidden(3,true);

    ui->pushButton_2->setEnabled(false);
}

dialogExplorerDir::~dialogExplorerDir()
{
    delete ui;
}

QString dialogExplorerDir::getPath() {
    return currentPath;
}


void dialogExplorerDir::on_treeView_clicked(const QModelIndex &index) {
    currentFile = model->fileInfo(index);
    if (!currentFile.isDir()) ui->pushButton_2->setEnabled(false);
    else ui->pushButton_2->setEnabled(true);
}

void dialogExplorerDir::on_pushButton_2_clicked() {
    if (currentFile.isDir()) currentPath = currentFile.absoluteFilePath();
    this->accept();
}
