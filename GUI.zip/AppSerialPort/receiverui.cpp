#include "receiverui.h"
#include "ui_receiverui.h"
#include "processingui.h"

#include <QDialog>
#include <QtCore>
#include <QtGui>

receiverUI::receiverUI(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::receiverUI)
{
    ui->setupUi(this);
    ui->textBrowser->setText("./");
    filePath = "./";
    ui->lineEdit_2->setText("B38400");

    newExp = new dialogExplorerDir();
    connect(newExp,SIGNAL(accepted()),this,SLOT(on_newExp_accepted()));
}

receiverUI::~receiverUI()
{
    delete ui;
}

void receiverUI::on_pushButton_clicked()
{
    newExp->show();
}

void receiverUI::on_newExp_accepted() {
    ui->textBrowser->setText(newExp->getPath());
    filePath = newExp->getPath().toStdString();
}

void receiverUI::on_pushButton_2_clicked()
{
    exit(-1);
}

void receiverUI::on_transf_accepted() {
    this->show();
}

void receiverUI::on_pushButton_3_clicked()
{
    int argc = 8;
    char **argv= new char*[argc];
    char temp[20];
    string path;

    for (int i = 0; i < argc; i++) argv[i] = new char[100];

    strcpy(argv[0], "nserial");
    strcpy(argv[1], "receiver");

    strcpy(argv[2], "-s");
    sprintf(temp, "%d",ui->spinBox_2->value());
    strcpy(argv[3], temp);

    if (ui->lineEdit_2->text().operator !=("B38400")) {
        strcpy(argv[4], "-b");
        strcpy(argv[5], (char *) ui->lineEdit_2->text().toStdString().c_str());
    } else argc -= 2;

    int i = 6;
    if (argc == 6) i-=2;

    if (ui->lineEdit->text() != "")  {
        strcpy(argv[i], "-l");
        path = filePath + "/" + ui->lineEdit->text().toStdString();
        strcpy(argv[i+1], (char *) path.c_str());
    } else {
        strcpy(argv[i], "-l");
        path = filePath;
        if (path.at(path.length()-1)!='/') path += "/";
        strcpy(argv[i+1], (char *) path.c_str());
    }

    appLayer * app = new appLayer();
    app->buildArgs(argc,argv);

    processingUI * transf = new processingUI();
    transf->setAppLayer(app);
    transf->show();
    this->hide();
    transf->setTransf(RECEIVER);

    connect(transf,SIGNAL(accepted()),this,SLOT(on_transf_accepted()));
}
