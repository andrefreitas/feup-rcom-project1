#include "appdialog.h"
#include "ui_appdialog.h"
#include "transmitterui.h"
#include "receiverui.h"

appDialog::appDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::appDialog)
{
    ui->setupUi(this);
}

appDialog::~appDialog()
{
    delete ui;
}


void appDialog::on_pushButton_clicked()
{
    transmitterUI * transmitter = new transmitterUI();
    transmitter->show();
    this->hide();
}

void appDialog::on_pushButton_2_clicked()
{
     receiverUI * receiver = new receiverUI();
     receiver->show();
     this->hide();
}
