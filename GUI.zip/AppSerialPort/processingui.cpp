#include "processingui.h"
#include "ui_processingui.h"

processingUI::processingUI(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::processingUI)
{
    ui->setupUi(this);
}

void processingUI::setAppLayer(appLayer *app) {
    this->app = app;
}

void processingUI::setTransf(int who) {
    ui->pushButton->setVisible(false);

    if (who == TRANSMITTER) app->sendFile();
    else if (who == RECEIVER) app ->receiveFile();
    app->showStats();

    this->setWindowTitle("");
    ui->pushButton->setVisible(true);
}

processingUI::~processingUI()
{
    delete ui;
}
