/********************************************************************************
** Form generated from reading UI file 'appdialog.ui'
**
** Created: Sun Oct 28 05:00:51 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APPDIALOG_H
#define UI_APPDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_appDialog
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label;

    void setupUi(QDialog *appDialog)
    {
        if (appDialog->objectName().isEmpty())
            appDialog->setObjectName(QString::fromUtf8("appDialog"));
        appDialog->resize(399, 152);
        pushButton = new QPushButton(appDialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(60, 90, 121, 27));
        pushButton_2 = new QPushButton(appDialog);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(214, 90, 121, 27));
        label = new QLabel(appDialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(90, 30, 221, 41));
        QFont font;
        font.setPointSize(9);
        label->setFont(font);

        retranslateUi(appDialog);

        QMetaObject::connectSlotsByName(appDialog);
    } // setupUi

    void retranslateUi(QDialog *appDialog)
    {
        appDialog->setWindowTitle(QApplication::translate("appDialog", "Liga\303\247\303\243o por Porta de S\303\251rie", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("appDialog", "Enviar Ficheiro", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("appDialog", "Receber Ficheiro", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("appDialog", "Escolha uma das seguintes op\303\247\303\265es:", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class appDialog: public Ui_appDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APPDIALOG_H
