/********************************************************************************
** Form generated from reading UI file 'receiverui.ui'
**
** Created: Sun Oct 28 05:00:51 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECEIVERUI_H
#define UI_RECEIVERUI_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_receiverUI
{
public:
    QPushButton *pushButton;
    QTextBrowser *textBrowser;
    QLabel *label;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QSpinBox *spinBox_2;
    QFrame *frame;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QDialog *receiverUI)
    {
        if (receiverUI->objectName().isEmpty())
            receiverUI->setObjectName(QString::fromUtf8("receiverUI"));
        receiverUI->resize(591, 341);
        receiverUI->setMinimumSize(QSize(591, 341));
        receiverUI->setMaximumSize(QSize(591, 341));
        receiverUI->setWindowOpacity(1);
        receiverUI->setSizeGripEnabled(true);
        pushButton = new QPushButton(receiverUI);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(460, 70, 85, 21));
        textBrowser = new QTextBrowser(receiverUI);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(50, 70, 391, 21));
        textBrowser->setFrameShape(QFrame::Box);
        label = new QLabel(receiverUI);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 150, 191, 21));
        label_3 = new QLabel(receiverUI);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(40, 30, 501, 41));
        QFont font;
        font.setPointSize(8);
        font.setBold(true);
        font.setWeight(75);
        label_3->setFont(font);
        label_3->setTextFormat(Qt::AutoText);
        label_3->setScaledContents(false);
        label_4 = new QLabel(receiverUI);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(70, 110, 371, 41));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        label_4->setFont(font1);
        label_4->setFrameShape(QFrame::NoFrame);
        label_4->setFrameShadow(QFrame::Plain);
        label_5 = new QLabel(receiverUI);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(340, 150, 191, 21));
        spinBox_2 = new QSpinBox(receiverUI);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        spinBox_2->setGeometry(QRect(140, 180, 101, 21));
        spinBox_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        spinBox_2->setMinimum(5);
        spinBox_2->setMaximum(4000);
        spinBox_2->setValue(4000);
        frame = new QFrame(receiverUI);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(50, 110, 491, 151));
        frame->setFrameShape(QFrame::Panel);
        frame->setFrameShadow(QFrame::Sunken);
        label_2 = new QLabel(frame);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 110, 171, 21));
        label_2->setFrameShape(QFrame::NoFrame);
        lineEdit = new QLineEdit(frame);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(220, 110, 181, 21));
        lineEdit_2 = new QLineEdit(frame);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(300, 70, 113, 21));
        pushButton_2 = new QPushButton(receiverUI);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(380, 290, 85, 27));
        pushButton_3 = new QPushButton(receiverUI);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(480, 290, 85, 27));
        frame->raise();
        pushButton->raise();
        textBrowser->raise();
        label->raise();
        label_3->raise();
        label_4->raise();
        label_5->raise();
        spinBox_2->raise();
        pushButton_2->raise();
        pushButton_3->raise();

        retranslateUi(receiverUI);

        QMetaObject::connectSlotsByName(receiverUI);
    } // setupUi

    void retranslateUi(QDialog *receiverUI)
    {
        receiverUI->setWindowTitle(QApplication::translate("receiverUI", "Receber Ficheiro", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("receiverUI", "Procurar", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("receiverUI", "Tamanho de blocos:", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("receiverUI", "Escolha s\303\255tio de destino para o ficheiro a receber:", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("receiverUI", "Op\303\247\303\265es adicionais:", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("receiverUI", "Baudrate:", 0, QApplication::UnicodeUTF8));
        spinBox_2->setSuffix(QApplication::translate("receiverUI", " bytes", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("receiverUI", "Novo nome (opcional) :", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("receiverUI", "Sair", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("receiverUI", "Receber", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class receiverUI: public Ui_receiverUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECEIVERUI_H
