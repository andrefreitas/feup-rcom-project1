/********************************************************************************
** Form generated from reading UI file 'dialogexplorerdir.ui'
**
** Created: Sun Oct 28 05:00:51 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGEXPLORERDIR_H
#define UI_DIALOGEXPLORERDIR_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QTreeView>

QT_BEGIN_NAMESPACE

class Ui_dialogExplorerDir
{
public:
    QTreeView *treeView;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *dialogExplorerDir)
    {
        if (dialogExplorerDir->objectName().isEmpty())
            dialogExplorerDir->setObjectName(QString::fromUtf8("dialogExplorerDir"));
        dialogExplorerDir->resize(519, 433);
        treeView = new QTreeView(dialogExplorerDir);
        treeView->setObjectName(QString::fromUtf8("treeView"));
        treeView->setGeometry(QRect(20, 20, 481, 351));
        pushButton = new QPushButton(dialogExplorerDir);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(310, 380, 85, 27));
        pushButton_2 = new QPushButton(dialogExplorerDir);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setEnabled(true);
        pushButton_2->setGeometry(QRect(410, 380, 85, 27));
        pushButton_2->setCheckable(false);

        retranslateUi(dialogExplorerDir);
        QObject::connect(pushButton, SIGNAL(clicked()), dialogExplorerDir, SLOT(accept()));

        QMetaObject::connectSlotsByName(dialogExplorerDir);
    } // setupUi

    void retranslateUi(QDialog *dialogExplorerDir)
    {
        dialogExplorerDir->setWindowTitle(QApplication::translate("dialogExplorerDir", "Explorador", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("dialogExplorerDir", "Cancelar", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("dialogExplorerDir", "OK", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class dialogExplorerDir: public Ui_dialogExplorerDir {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGEXPLORERDIR_H
