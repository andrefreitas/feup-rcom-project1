/********************************************************************************
** Form generated from reading UI file 'processing.ui'
**
** Created: Sun Oct 28 05:00:51 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROCESSING_H
#define UI_PROCESSING_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_processing
{
public:
    QLabel *label;

    void setupUi(QDialog *processing)
    {
        if (processing->objectName().isEmpty())
            processing->setObjectName(QString::fromUtf8("processing"));
        processing->resize(521, 163);
        label = new QLabel(processing);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(160, 60, 301, 51));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);

        retranslateUi(processing);

        QMetaObject::connectSlotsByName(processing);
    } // setupUi

    void retranslateUi(QDialog *processing)
    {
        processing->setWindowTitle(QApplication::translate("processing", "Transfer\303\252ncia", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("processing", "A transferir...", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class processing: public Ui_processing {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROCESSING_H
