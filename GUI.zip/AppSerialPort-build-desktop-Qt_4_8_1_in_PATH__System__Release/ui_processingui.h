/********************************************************************************
** Form generated from reading UI file 'processingui.ui'
**
** Created: Mon Oct 29 01:12:33 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROCESSINGUI_H
#define UI_PROCESSINGUI_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_processingUI
{
public:
    QLabel *label;
    QPushButton *pushButton;

    void setupUi(QDialog *processingUI)
    {
        if (processingUI->objectName().isEmpty())
            processingUI->setObjectName(QString::fromUtf8("processingUI"));
        processingUI->resize(204, 89);
        label = new QLabel(processingUI);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 10, 191, 31));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        pushButton = new QPushButton(processingUI);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(60, 40, 85, 27));

        retranslateUi(processingUI);
        QObject::connect(pushButton, SIGNAL(clicked()), processingUI, SLOT(accept()));

        QMetaObject::connectSlotsByName(processingUI);
    } // setupUi

    void retranslateUi(QDialog *processingUI)
    {
        processingUI->setWindowTitle(QApplication::translate("processingUI", "A transferir...", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("processingUI", "Transfer\303\252ncia conclu\303\255da!", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("processingUI", "OK", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class processingUI: public Ui_processingUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROCESSINGUI_H
