/********************************************************************************
** Form generated from reading UI file 'transmitterui.ui'
**
** Created: Sun Oct 28 05:00:51 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRANSMITTERUI_H
#define UI_TRANSMITTERUI_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_transmitterUI
{
public:
    QPushButton *pushButton;
    QTextBrowser *textBrowser;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QCheckBox *checkBox;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QSpinBox *spinBox_4;
    QSpinBox *spinBox_5;
    QFrame *frame;
    QLineEdit *lineEdit;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QDialog *transmitterUI)
    {
        if (transmitterUI->objectName().isEmpty())
            transmitterUI->setObjectName(QString::fromUtf8("transmitterUI"));
        transmitterUI->resize(591, 373);
        transmitterUI->setMinimumSize(QSize(591, 373));
        transmitterUI->setMaximumSize(QSize(591, 373));
        transmitterUI->setWindowOpacity(1);
        transmitterUI->setSizeGripEnabled(true);
        pushButton = new QPushButton(transmitterUI);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(460, 70, 85, 21));
        textBrowser = new QTextBrowser(transmitterUI);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(50, 70, 391, 21));
        textBrowser->setFrameShape(QFrame::Box);
        label = new QLabel(transmitterUI);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(230, 160, 171, 21));
        label_2 = new QLabel(transmitterUI);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(80, 160, 121, 21));
        label_2->setFrameShape(QFrame::NoFrame);
        label_3 = new QLabel(transmitterUI);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(40, 30, 471, 41));
        QFont font;
        font.setPointSize(8);
        font.setBold(true);
        font.setWeight(75);
        label_3->setFont(font);
        label_3->setTextFormat(Qt::AutoText);
        label_3->setScaledContents(false);
        label_4 = new QLabel(transmitterUI);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(70, 120, 271, 41));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        label_4->setFont(font1);
        label_4->setFrameShape(QFrame::NoFrame);
        label_4->setFrameShadow(QFrame::Plain);
        label_5 = new QLabel(transmitterUI);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(410, 160, 121, 21));
        label_6 = new QLabel(transmitterUI);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(230, 220, 171, 21));
        label_7 = new QLabel(transmitterUI);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(410, 220, 121, 21));
        checkBox = new QCheckBox(transmitterUI);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(80, 240, 201, 21));
        checkBox->setIconSize(QSize(20, 20));
        checkBox->setTristate(false);
        spinBox = new QSpinBox(transmitterUI);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(80, 190, 61, 21));
        spinBox->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        spinBox->setMaximum(15);
        spinBox->setValue(1);
        spinBox_2 = new QSpinBox(transmitterUI);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        spinBox_2->setGeometry(QRect(240, 190, 101, 21));
        spinBox_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        spinBox_2->setMinimum(5);
        spinBox_2->setMaximum(4000);
        spinBox_2->setValue(4000);
        spinBox_4 = new QSpinBox(transmitterUI);
        spinBox_4->setObjectName(QString::fromUtf8("spinBox_4"));
        spinBox_4->setGeometry(QRect(290, 250, 51, 21));
        spinBox_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        spinBox_4->setMinimum(1);
        spinBox_4->setMaximum(100);
        spinBox_4->setValue(3);
        spinBox_5 = new QSpinBox(transmitterUI);
        spinBox_5->setObjectName(QString::fromUtf8("spinBox_5"));
        spinBox_5->setGeometry(QRect(450, 250, 71, 21));
        spinBox_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        spinBox_5->setMinimum(0);
        spinBox_5->setMaximum(100);
        spinBox_5->setValue(5);
        frame = new QFrame(transmitterUI);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(50, 110, 491, 191));
        frame->setFrameShape(QFrame::Panel);
        frame->setFrameShadow(QFrame::Sunken);
        lineEdit = new QLineEdit(frame);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(352, 80, 111, 21));
        lineEdit->setFrame(true);
        pushButton_2 = new QPushButton(transmitterUI);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(380, 320, 85, 27));
        pushButton_3 = new QPushButton(transmitterUI);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(480, 320, 85, 27));
        frame->raise();
        pushButton->raise();
        textBrowser->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        label_4->raise();
        label_5->raise();
        label_6->raise();
        label_7->raise();
        checkBox->raise();
        spinBox->raise();
        spinBox_2->raise();
        spinBox_4->raise();
        spinBox_5->raise();
        pushButton_2->raise();
        pushButton_3->raise();

        retranslateUi(transmitterUI);

        QMetaObject::connectSlotsByName(transmitterUI);
    } // setupUi

    void retranslateUi(QDialog *transmitterUI)
    {
        transmitterUI->setWindowTitle(QApplication::translate("transmitterUI", "Enviar Ficheiro", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("transmitterUI", "Procurar", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("transmitterUI", "Tamanho de blocos:", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("transmitterUI", "Timeout:", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("transmitterUI", "Escolha um ficheiro a enviar:", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("transmitterUI", "Op\303\247\303\265es adicionais:", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("transmitterUI", "Baudrate:", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("transmitterUI", "N\303\272mero de tentativas:", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("transmitterUI", "Induzir erro:", 0, QApplication::UnicodeUTF8));
        checkBox->setText(QApplication::translate("transmitterUI", "Retransmiss\303\243o", 0, QApplication::UnicodeUTF8));
        spinBox->setSuffix(QApplication::translate("transmitterUI", " s", 0, QApplication::UnicodeUTF8));
        spinBox_2->setSuffix(QApplication::translate("transmitterUI", " bytes", 0, QApplication::UnicodeUTF8));
        spinBox_4->setSuffix(QString());
        spinBox_5->setSuffix(QApplication::translate("transmitterUI", " %", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("transmitterUI", "Sair", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("transmitterUI", "Enviar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class transmitterUI: public Ui_transmitterUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRANSMITTERUI_H
