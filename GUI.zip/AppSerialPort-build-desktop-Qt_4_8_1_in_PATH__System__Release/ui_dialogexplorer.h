/********************************************************************************
** Form generated from reading UI file 'dialogexplorer.ui'
**
** Created: Sun Oct 28 05:00:51 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGEXPLORER_H
#define UI_DIALOGEXPLORER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QTreeView>

QT_BEGIN_NAMESPACE

class Ui_dialogExplorer
{
public:
    QTreeView *treeView;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *dialogExplorer)
    {
        if (dialogExplorer->objectName().isEmpty())
            dialogExplorer->setObjectName(QString::fromUtf8("dialogExplorer"));
        dialogExplorer->resize(519, 433);
        treeView = new QTreeView(dialogExplorer);
        treeView->setObjectName(QString::fromUtf8("treeView"));
        treeView->setGeometry(QRect(20, 20, 481, 351));
        pushButton = new QPushButton(dialogExplorer);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(310, 380, 85, 27));
        pushButton_2 = new QPushButton(dialogExplorer);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setEnabled(true);
        pushButton_2->setGeometry(QRect(410, 380, 85, 27));
        pushButton_2->setCheckable(false);

        retranslateUi(dialogExplorer);
        QObject::connect(pushButton, SIGNAL(clicked()), dialogExplorer, SLOT(accept()));

        QMetaObject::connectSlotsByName(dialogExplorer);
    } // setupUi

    void retranslateUi(QDialog *dialogExplorer)
    {
        dialogExplorer->setWindowTitle(QApplication::translate("dialogExplorer", "Explorador", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("dialogExplorer", "Cancelar", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("dialogExplorer", "OK", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class dialogExplorer: public Ui_dialogExplorer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGEXPLORER_H
